﻿myFunction([
{
"display": "HTML Tutorial",
"url": "http://www.w3schools.com/html/default.asp"
},
{
"display": "CSS Tutorial",
"url": "http://www.w3schools.com/css/default.asp"
},
{
"display": "JavaScript Tutorial",
"url": "http://www.w3schools.com/js/default.asp"
},
{
"display": "jQuery Tutorial",
"url": "http://www.w3schools.com/jquery/default.asp"
},
{
"display": "JSON Tutorial",
"url": "http://www.w3schools.com/json/default.asp"
},
{
"display": "AJAX Tutorial",
"url": "http://www.w3schools.com/ajax/default.asp"
},
{
"display": "SQL Tutorial",
"url": "http://www.w3schools.com/sql/default.asp"
},
{
"display": "PHP Tutorial",
"url": "http://www.w3schools.com/php/default.asp"
},
{
"display": "XML Tutorial",
"url": "http://www.w3schools.com/xml/default.asp"
}
])