<!DOCTYPE html>
<html>
<body>

Volvo: In stock: 22, sold: 18.<br>BMW: In stock: 15, sold: 13.<br>Saab: In stock: 5, sold: 2.<br>Land Rover: In stock: 17, sold: 15.<br>
</body>
</html>