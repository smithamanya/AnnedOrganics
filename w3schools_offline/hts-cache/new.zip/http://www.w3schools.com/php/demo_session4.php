<!DOCTYPE html>
<html>
<body>

Array
(
    [favcolor] => yellow
    [favanimal] => cat
)

</body>
</html>