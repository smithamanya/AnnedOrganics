<!DOCTYPE html>
<html>
<body>

<table style='border: solid 1px black;'>
<tr>
<th>Id</th><th>Firstname</th><th>Lastname</th>
</tr>
<tr>
<td style='width: 150px; border: 1px solid black;'>1</td>
<td style='width: 150px; border: 1px solid black;'>John</td>
<td style='width: 150px; border: 1px solid black;'>Doe</td>
</tr>
<tr>
<td style='width: 150px; border: 1px solid black;'>2</td>
<td style='width: 150px; border: 1px solid black;'>Mary</td>
<td style='width: 150px; border: 1px solid black;'>Moe</td>
</tr>
<tr>
<td style='width: 150px; border: 1px solid black;'>3</td>
<td style='width: 150px; border: 1px solid black;'>Julie</td>
<td style='width: 150px; border: 1px solid black;'>Dooley</td>
</table>  

</body>
</html>