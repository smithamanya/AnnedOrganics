<!DOCTYPE html>
<html>
<body>

Key=Joe, Value=43<br>Key=Ben, Value=37<br>Key=Peter, Value=35<br>
</body>
</html>