<!DOCTYPE html>
<html>
<body>

I like Volvo, BMW and Toyota.
</body>
</html>