<!DOCTYPE html>
<html>
<body>

The number is: 0 <br>The number is: 1 <br>The number is: 2 <br>The number is: 3 <br>The number is: 4 <br>The number is: 5 <br>The number is: 6 <br>The number is: 7 <br>The number is: 8 <br>The number is: 9 <br>The number is: 10 <br>  

</body>
</html>