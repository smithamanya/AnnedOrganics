<!DOCTYPE html>
<html>
<head>
<style>
table, th, td {
    border: 1px solid black;
    border-collapse: collapse;
}
th, td {
    padding: 5px;
}
</style>
</head>
<body>

<table>
  <tr>
    <td>Filter Name</td>
    <td>Filter ID</td>
  </tr>
  <tr><td>int</td><td>257</td></tr><tr><td>boolean</td><td>258</td></tr><tr><td>float</td><td>259</td></tr><tr><td>validate_regexp</td><td>272</td></tr><tr><td>validate_url</td><td>273</td></tr><tr><td>validate_email</td><td>274</td></tr><tr><td>validate_ip</td><td>275</td></tr><tr><td>string</td><td>513</td></tr><tr><td>stripped</td><td>513</td></tr><tr><td>encoded</td><td>514</td></tr><tr><td>special_chars</td><td>515</td></tr><tr><td>full_special_chars</td><td>522</td></tr><tr><td>unsafe_raw</td><td>516</td></tr><tr><td>email</td><td>517</td></tr><tr><td>url</td><td>518</td></tr><tr><td>number_int</td><td>519</td></tr><tr><td>number_float</td><td>520</td></tr><tr><td>magic_quotes</td><td>521</td></tr><tr><td>callback</td><td>1024</td></tr></table>

</body>
</html>