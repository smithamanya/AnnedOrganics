<!DOCTYPE html>
<html>
<body>

Cookies are enabled.
</body>
</html>