<!DOCTYPE html>
<html>
<body>

Favorite color is green.<br>Favorite animal is cat.
</body>
</html>