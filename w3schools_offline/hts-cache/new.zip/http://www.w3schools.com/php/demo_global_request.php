<!DOCTYPE html>
<html>
<body>

<form method="post" action="/php/demo_global_request.php">
  Name: <input type="text" name="fname">
  <input type="submit">
</form>


</body>
</html>