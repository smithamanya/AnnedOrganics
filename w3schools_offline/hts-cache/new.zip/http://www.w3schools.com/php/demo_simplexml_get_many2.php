<!DOCTYPE html>
<html>
<body>

Everyday Italian, Giada De Laurentiis, 2005, 30.00<br>Harry Potter, J K. Rowling, 2005, 29.99<br>XQuery Kick Start, James McGovern, 2003, 49.99<br>Learning XML, Erik T. Ray, 2003, 39.95<br> 

</body>
</html>