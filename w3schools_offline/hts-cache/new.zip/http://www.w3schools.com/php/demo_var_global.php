<!DOCTYPE html>
<html>
<body>

<p>Variable x inside function is: </p><p>Variable x outside function is: 5</p>
</body>
</html>