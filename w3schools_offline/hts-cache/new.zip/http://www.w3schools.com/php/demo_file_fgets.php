<!DOCTYPE html>
<html>
<body>

AJAX = Asynchronous JavaScript and XML

</body>
</html>