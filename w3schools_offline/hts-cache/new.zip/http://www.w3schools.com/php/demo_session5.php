<!DOCTYPE html>
<html>
<body>

All session variables are now removed, and the session is destroyed.
</body>
</html>