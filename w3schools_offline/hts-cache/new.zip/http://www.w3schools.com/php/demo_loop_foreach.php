<!DOCTYPE html>
<html>
<body>

red <br>green <br>blue <br>yellow <br>  

</body>
</html>