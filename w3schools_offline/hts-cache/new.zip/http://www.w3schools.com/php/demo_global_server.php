<!DOCTYPE html>
<html>
<body>

/php/demo_global_server.php<br>www.w3schools.com<br>www.w3schools.com<br>http://www.w3schools.com/php/showphp.asp?filename=demo_global_server<br>Mozilla/4.5 (compatible; HTTrack 3.0x; Windows 98)<br>/php/demo_global_server.php
</body>
</html>