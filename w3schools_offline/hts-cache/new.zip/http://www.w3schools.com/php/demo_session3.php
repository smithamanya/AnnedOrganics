<!DOCTYPE html>
<html>
<body>

Array
(
    [favcolor] => green
    [favanimal] => cat
)

</body>
</html>