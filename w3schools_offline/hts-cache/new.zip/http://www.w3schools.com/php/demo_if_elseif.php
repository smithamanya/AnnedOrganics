<!DOCTYPE html>
<html>
<body>

<p>The hour (of the server) is 05, and will give the following message:</p>Have a good morning! 
</body>
</html>