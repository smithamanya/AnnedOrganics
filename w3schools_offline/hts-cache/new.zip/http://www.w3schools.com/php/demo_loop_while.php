<!DOCTYPE html>
<html>
<body>

The number is: 1 <br>The number is: 2 <br>The number is: 3 <br>The number is: 4 <br>The number is: 5 <br>  

</body>
</html>