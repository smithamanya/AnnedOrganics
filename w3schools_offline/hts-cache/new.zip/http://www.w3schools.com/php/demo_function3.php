<!DOCTYPE html>
<html>
<body>

Hege Refsnes. Born in 1975 <br>Stale Refsnes. Born in 1978 <br>Kai Jim Refsnes. Born in 1983 <br>
</body>
</html>