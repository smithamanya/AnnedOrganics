<!DOCTYPE html>
<html>
<body>

Cookie 'user' is set!<br>Value is: John Doe
<p><strong>Note:</strong> You might have to reload the page to see the new value of the cookie.</p>

</body>
</html>