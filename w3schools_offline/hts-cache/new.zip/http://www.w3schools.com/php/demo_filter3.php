<!DOCTYPE html>
<html>
<body>

Integer is valid
</body>
</html>