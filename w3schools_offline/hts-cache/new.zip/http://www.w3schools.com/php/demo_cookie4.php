<!DOCTYPE html>
<html>
<body>

Cookie 'user' is deleted.
</body>
</html>