<!DOCTYPE html>
<html>
<body>

-- Note --<br>
    To: Tove<br>
    From: Jani<br>
    Heading: Reminder<br>
    Message: Don't forget me this weekend!<br>
<br>
</body>
</html>