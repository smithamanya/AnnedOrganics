<!DOCTYPE html>
<html>
<body>

<h1>Welcome to my home page!</h1>
I have a  .
</body>
</html>