<!DOCTYPE html>
<html>
<body>

Key=Peter, Value=35<br>Key=Ben, Value=37<br>Key=Joe, Value=43<br>
</body>
</html>