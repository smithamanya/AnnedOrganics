<!DOCTYPE html>
<html>
<body>

http://www.w3schools.com is a valid URL
</body>
</html>