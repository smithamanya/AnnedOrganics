<!DOCTYPE html>
<html>
<body>

The number is: 6 <br>
</body>
</html>