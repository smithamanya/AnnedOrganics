<!DOCTYPE html>
<html>
<body>

float(10.365)
  

</body>
</html>