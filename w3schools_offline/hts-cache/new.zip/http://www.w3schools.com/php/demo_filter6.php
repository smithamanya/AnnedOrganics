<!DOCTYPE html>
<html>
<body>

john.doe@example.com is a valid email address
</body>
</html>