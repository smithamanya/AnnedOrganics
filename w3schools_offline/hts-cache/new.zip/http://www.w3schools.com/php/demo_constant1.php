<!DOCTYPE html>
<html>
<body>

Welcome to W3Schools.com! 

</body>
</html>