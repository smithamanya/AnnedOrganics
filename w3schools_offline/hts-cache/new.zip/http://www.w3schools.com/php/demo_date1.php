<!DOCTYPE html>
<html>
<body>

Today is 2016/01/19<br>Today is 2016.01.19<br>Today is 2016-01-19<br>Today is Tuesday
</body>
</html>