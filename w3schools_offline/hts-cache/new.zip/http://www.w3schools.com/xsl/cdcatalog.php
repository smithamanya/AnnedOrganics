<html><body>
<h2>My CD Collection</h2>
<table border="1">
<tr bgcolor="#9acd32">
<th style="text-align:left">Title</th>
<th style="text-align:left">Artist</th>
</tr>
<tr>
<td>Empire Burlesque</td>
<td>Bob Dylan</td>
</tr>
<tr>
<td>Hide your heart</td>
<td>Bonnie Tyler</td>
</tr>
<tr>
<td>Greatest Hits</td>
<td>Dolly Parton</td>
</tr>
<tr>
<td>Still got the blues</td>
<td>Gary Moore</td>
</tr>
<tr>
<td>Eros</td>
<td>Eros Ramazzotti</td>
</tr>
<tr>
<td>One night only</td>
<td>Bee Gees</td>
</tr>
<tr>
<td>Sylvias Mother</td>
<td>Dr.Hook</td>
</tr>
<tr>
<td>Maggie May</td>
<td>Rod Stewart</td>
</tr>
<tr>
<td>Romanza</td>
<td>Andrea Bocelli</td>
</tr>
<tr>
<td>When a man loves a woman</td>
<td>Percy Sledge</td>
</tr>
<tr>
<td>Black angel</td>
<td>Savage Rose</td>
</tr>
<tr>
<td>1999 Grammy Nominees</td>
<td>Many</td>
</tr>
<tr>
<td>For the good times</td>
<td>Kenny Rogers</td>
</tr>
<tr>
<td>Big Willie style</td>
<td>Will Smith</td>
</tr>
<tr>
<td>Tupelo Honey</td>
<td>Van Morrison</td>
</tr>
<tr>
<td>Soulsville</td>
<td>Jorn Hoel</td>
</tr>
<tr>
<td>The very best of</td>
<td>Cat Stevens</td>
</tr>
<tr>
<td>Stop</td>
<td>Sam Brown</td>
</tr>
<tr>
<td>Bridge of Spies</td>
<td>T`Pau</td>
</tr>
<tr>
<td>Private Dancer</td>
<td>Tina Turner</td>
</tr>
<tr>
<td>Midt om natten</td>
<td>Kim Larsen</td>
</tr>
<tr>
<td>Pavarotti Gala Concert</td>
<td>Luciano Pavarotti</td>
</tr>
<tr>
<td>The dock of the bay</td>
<td>Otis Redding</td>
</tr>
<tr>
<td>Picture book</td>
<td>Simply Red</td>
</tr>
<tr>
<td>Red</td>
<td>The Communards</td>
</tr>
<tr>
<td>Unchain my heart</td>
<td>Joe Cocker</td>
</tr>
</table>
</body></html>
 